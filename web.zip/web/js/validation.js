var oldColor;
var oldFontW;
function newStudentForm(){

var carnet = document.forms["newStudent"]["pCarnet"].value;
var surName = document.forms["newStudent"]["pSurName"].value;
var name = document.forms["newStudent"]["pName"].value;
if (carnet===null || carnet==="")
    alert("Falta Informacion de Carnet");
else if (surName===null || surName==="")
    alert("Debe Llenar los Apellidos");
else if (name===null || name==="")
    alert("Debe Llenar El Nombre");
else document.forms["newStudent"].submit();
};

function effect(ele){
    e = document.getElementById(ele);
    e.style.color= "red";
    e.style.fontWeight = "bold";
    e.style.textDecoration ="underline";
};
function deefect(e){
    e.style.color= "black";
    e.style.fontWeight = "normal";
    e.style.textDecoration ="none";
}